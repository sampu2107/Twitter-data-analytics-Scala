import twitter4j.TwitterFactory
import twitter4j.Twitter
import twitter4j.conf.ConfigurationBuilder
import twitter4j._
import java.text.SimpleDateFormat
import java.util.SimpleTimeZone
import java.util.Properties
import java.nio._
import java.nio.file.StandardOpenOption
import java.nio.file.Paths
import twitter4j.conf.ConfigurationBuilder
//import play.api.libs.json._
import com.google.gson.Gson
import java.util.ArrayList
import scala.collection.mutable.ListBuffer
import twitter4j.json.DataObjectFactory;
import scala.collection.mutable.StringBuilder

import org.slf4j.LoggerFactory
import ch.qos.logback.core.util.StatusPrinter
import ch.qos.logback.classic.LoggerContext

//case class TwitterObject(userid: String, tweet: String)
case class TwitterObject(tweet: String)

object tweets {
  
  def main(args : Array[String]) {
    
   // ArrayList<Status> tweets = new ArrayList<Status>();
    var tweeets = new ListBuffer[Status]();
    var gson = new Gson();
    // (1) config work to create a twitter object
    var cb = new ConfigurationBuilder()
    cb.setJSONStoreEnabled(true);
    cb.setDebugEnabled(true)
      .setOAuthConsumerKey("YHSar9mvzdpEVNe5SYFs5Ii4Z")
		.setOAuthConsumerSecret("MxkCd6Oh2Y7ZIRAtfKxxPecOyiG2DYf9Qrh8Lj5cGUPU40f07y")
		.setOAuthAccessToken("1366744135-qTpURkPwcXU1TpWgmA9zAKLW7IGIahEy0qk6sXs")
		.setOAuthAccessTokenSecret("yDMSychbV7Ipktsk2on2FX5WAdbrlfzs8qN7EjSLrAO9l")
		.setIncludeEntitiesEnabled(true)
     var tf = new TwitterFactory(cb.build())
    var twitter = tf.getInstance()
    var query = new Query("US Elections Hillary Trump")
    query.setCount(50);
    //query.setSince("2016-10-01");
    //query.setUntil("2016-11-16");
    //query.geoCode(new GeoLocation(XXX, XXX), 200, Query.KILOMETERS);
    var result = twitter.search(query)
    System.out.println("Showing results.")
    //println("count********"+result.getCount);
    //println("count********"+result);
    /*val p = TwitterObject("Ajay","");
    val p1 = TwitterObject("Ajay",""); */
   
    var jsonString = "";
    jsonString.addString(new StringBuilder("["));
    
  while (result.hasNext()) {
    var it = result.getTweets.iterator()
      while(it.hasNext()){
        println("---------"+it.next().getText())
          System.setProperty("logback.configurationFile", "C:/Users/werms/workspace/Scala/Twitter/resource/logback.xml");
  
  def logger = LoggerFactory.getLogger(this.getClass)

  // The following line prints startup information from logback if anything should go amiss
  StatusPrinter.print((LoggerFactory.getILoggerFactory).asInstanceOf[LoggerContext])

  println("- About to log!")
 // logger.info()
         // if(it.next().getLang == "en"){ 
        println(it)
         var json = DataObjectFactory.getRawJSON(result.getTweets)
        println(json)
		 var p = TwitterObject(it.next().getText);
         jsonString = gson.toJson(p);
         //sjsonString
		 //jsonString.addString(",")
         jsonString.addString(new StringBuilder(","));
        println(jsonString.addString(new StringBuilder(","+gson.toJson(p))));
      
    }}
      
     jsonString.addString(new StringBuilder("]"));  
      



    
    
    
    //while (result.hasNext()) {
   //it = result.getTweets.iterator()
     /* while(it.hasNext()){
 //        if(it.next().getLang == "en"){ 
        //s println(it.next().getText)
   //    }
    }*/
       // System.out.println(tweet.getFromUser() + ":" + tweet.getText());
        //val json = DataObjectFactory.getRawJSON(it);
        //System.out.println(json);
   // }

    //}
}
}