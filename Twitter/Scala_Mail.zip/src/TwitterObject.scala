/*
object TwitterObject {
    val id = null;
    public Integer listed_count;
    public String screen_name;
    public String url;
    public Integer followers_count;
    public Integer friends_count;
    public Integer statuses_count; 
}*/